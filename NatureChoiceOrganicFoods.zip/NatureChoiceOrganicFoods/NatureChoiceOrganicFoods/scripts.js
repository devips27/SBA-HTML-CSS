
//Javascript for homepage.html, login.html and registration.html

function myFunction() {

	//Used collection as per requirement
        var myCollection = document.getElementsByClassName("a1");
                
        myCollection[3].style.color = "red";
    }

function mynewFunction() { 
	//Used collection and for loop as per requirement
	var locs = ["Exton", "Malvern", "Wilmington", "Downingtown"];
	var i, len, text;
	for (i = 0, len = locs.length, text = ""; i < len; i++) {
  		text += locs[i] + "<br>";
		}
	document.getElementById("b2").innerHTML = text;       
	}     
   

function validateloginform()

{ 
//used variable as per requirement
var uname=document.login.Uname.value;
var pass=document.login.Pass.value;
//used if loop as per requirement
if(uname==null || uname==""){  
  alert("User Name can't be blank");  
  return false;  
    }
    else {

        var username = document.getElementById('Uname').value;

      }
 if(pass==null || pass.length<6){  
  alert("Password should not be blank and must be at least 6 characters long.");  
  return false;  
  } 
   else {

        var password = document.getElementById('Pass').value;

      }
	alert('Login Successful for ' + username);

}


function validateform()
{  
var fname=document.register.fname.value;
var lname=document.register.lname.value;
var uname=document.register.uname.value;
var pass=document.register.pass.value;
var cpass=document.register.cpass.value;
var ct=document.register.ct.value;
var mno=document.register.mno.value;
 
var x=document.register.email.value;  
var atposition=x.indexOf("@");  
var dotposition=x.lastIndexOf("."); 
// Used regex validation as per requirement
var numbers = /^[0-9]+$/; 
var letters = /^[a-zA-Z0-9]+$/;
  
  if (fname==null || fname==""){  
  alert("First Name can't be blank");  
  return false; 
  } 
  else {

        var fname1 = document.getElementById('fname').value;

      }
    
  if(lname==null || lname==""){  
  alert("Last Name can't be blank");  
  return false;  
    }
    else {

        var lname1 = document.getElementById('lname').value;

      }
  
  if(uname.match(letters))
  {
    var uname1 = document.getElementById('uname').value;
  }
    else
  {
    alert("User name should be alphabet or numeric and cant be blank");

    return false;
  } 
  if(pass==null || pass.length<6){  
  alert("Password should not be blank and must be at least 6 characters long.");  
  return false;  
  }  
  else {

        var pass1 = document.getElementById('pass').value;

      }
  if (pass != cpass)
	{
		alert ("Password did not match");
         return false;
    }
  else {

        var pass2 = document.getElementById('cpass').value;
    }

  if (atposition<1 || dotposition<atposition+2 || dotposition+2>=x.length){  
  alert("Please enter a valid e-mail address \n atpostion:"+atposition+"\n dotposition:"+dotposition);  
  return false;  
  } 
  else {

        var email1 = document.getElementById('email').value;

      }
   if (mno.match(numbers))
  {
  var mno1 = document.getElementById('mno').value;

  }
  else
  {
  alert("Mobile number must be numeric and cant be blank");
  return false;
  }
  if(ct == "Default")
  {
  alert('Select your city from the list');
  return false;
    }
  else {

        var ct1 = document.getElementById('ct').value;

      }
 
   
  alert('Form Succesfully Submitted');

    
}